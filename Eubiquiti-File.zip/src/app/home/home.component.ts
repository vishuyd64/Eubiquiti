import { Component, OnInit } from '@angular/core';
declare var $ : any;
declare function scroll(): any;
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    // scroll tab 
$(".section1").click(function() {
	$('html, body').animate({
	scrollTop: $(".class1").offset().top
	}, 1000);
	});
	$(".section2").click(function() {
	$('html, body').animate({
	scrollTop: $(".class2").offset().top
	}, 1000);
	});
	$(".section3").click(function() {
	$('html, body').animate({
	scrollTop: $(".class3").offset().top
	}, 1000);
	});
	$(".section4").click(function() {
	$('html, body').animate({
	scrollTop: $(".class4").offset().top
	}, 1000);
	});
// scroll tab end
	scroll();
  }

}
