import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-alt',
  templateUrl: './footer-alt.component.html',
  styleUrls: ['./footer-alt.component.scss']
})
export class FooterAltComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
