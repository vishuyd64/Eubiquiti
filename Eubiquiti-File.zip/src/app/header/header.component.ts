import { Component, OnInit } from '@angular/core';
declare var $:any;
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {

    $(document).on('click','ul li a',() =>{
      $('ul li a').removeClass('active');
      $(this).addClass('active');
    });


    // $(document).on('click','ul li a',() =>{
    //   $('ul li a').removeClass('active');
    //   $(this).addClass('active');
    // });
  }

}
