import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-alt',
  templateUrl: './header-alt.component.html',
  styleUrls: ['./header-alt.component.scss']
})
export class HeaderAltComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
