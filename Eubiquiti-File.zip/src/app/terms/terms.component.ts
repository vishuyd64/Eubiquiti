import { Component, OnInit } from '@angular/core';
declare var $:any;
@Component({
  selector: 'app-terms',
  templateUrl: './terms.component.html',
  styleUrls: ['./terms.component.scss']
})
export class TermsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
        // scroll tab 
$(".section1").click(function() {
	$('html, body').animate({
	scrollTop: $(".class1").offset().top
	}, 1000);
	});
	$(".section2").click(function() {
	$('html, body').animate({
	scrollTop: $(".class2").offset().top
	}, 1000);
	});
	$(".section3").click(function() {
	$('html, body').animate({
	scrollTop: $(".class3").offset().top
	}, 1000);
	});
	$(".section4").click(function() {
	$('html, body').animate({
	scrollTop: $(".class4").offset().top
	}, 1000);
	});
// scroll tab end
  }

}
